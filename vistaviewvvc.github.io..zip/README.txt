BrightView Window Cleaning — Website package
-------------------------------------------

Files included:
- index.html
- styles.css
- script.js
- README.txt

How to use:
1. Unzip the package into a folder on your computer or your web server's document root.
2. Replace placeholder images by adding your images into an 'assets' folder and updating <div class="hero-image"> in index.html or using <img>.
3. The contact form is front-end only and demonstrates validation. To receive messages:
   - Option A (no-code): Use a form provider (Formspree, Getform, Netlify Forms) and update the form "action" attribute.
   - Option B (standard): Point the form to your backend endpoint (POST) which handles form submissions and sends emails.
4. Deploy: upload to any static host (Netlify, Vercel, GitHub Pages) or a traditional web server.

Suggestions to keep it professional:
- Use a real business phone number and email in the contact section.
- Replace the placeholder hero image with a bright, high-res photo of your team or a close-up of cleaning.
- Add structured data (JSON-LD) for LocalBusiness if you want better local SEO.
- Consider adding a simple CMS or Google Maps embed for directions.

If you'd like:
- I can add a working contact endpoint (example Node/Express) or set this up with Formspree.
- Create social icons and link to your Facebook/Instagram/Google Business profile.
- Generate a matching logo and hero image optimized for web.

