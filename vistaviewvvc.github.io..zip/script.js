// script.js — lightweight interactivity and form handling (no backend)
// Toggle mobile nav
document.addEventListener('DOMContentLoaded', function(){
  const navToggle = document.getElementById('nav-toggle');
  const navList = document.getElementById('nav-list');
  navToggle && navToggle.addEventListener('click', function(){
    const expanded = this.getAttribute('aria-expanded') === 'true';
    this.setAttribute('aria-expanded', String(!expanded));
    navList.style.display = expanded ? '' : 'flex';
  });

  // Set year in footer
  const yearEl = document.getElementById('year');
  if(yearEl) yearEl.textContent = new Date().getFullYear();

  // Simple front-end form handling (replace with real endpoint)
  const form = document.getElementById('contact-form');
  const status = document.getElementById('form-status');
  form && form.addEventListener('submit', function(e){
    e.preventDefault();
    status.textContent = 'Sending...';

    // Basic validation
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    if(!name || !email){
      status.textContent = 'Please include your name and email.';
      return;
    }

    // Simulate form submission (replace with fetch to your server or form provider)
    setTimeout(function(){
      status.textContent = 'Thanks — your request has been received. We will contact you within 1 business day.';
      form.reset();
    }, 900);
  });
});
